----------
By Vaillant
----------

Ouvrez le fichier "installer.exe"
-------------------------------------------
puis vous ouvrez le fichier "Sender OnOff.exe"

bon spam à toi :) 